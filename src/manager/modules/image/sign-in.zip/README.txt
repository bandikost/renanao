A Pen created at CodePen.io. You can find this one at https://codepen.io/mariosmaselli/pen/GlvKs.

 Sign in inspired on @polanquette dribbble https://dribbble.com/shots/1578521-Sign-In-Shot?list=users&offset=0